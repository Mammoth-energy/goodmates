# EXECUTION CHECKLIST｜90-Day Store Launch

Priority: P0 = must be done first; P1 = important; P2 = support item.

## Week 1–2｜Project setup and supplier confirmation
| Priority | Task | Output |
|---|---|---|
| P0 | Confirm central kitchen contact and decision-maker | Tom confirmed |
| P0 | Request standard supply agreement / onboarding pack | Contract framework received |
| P0 | Collect central kitchen compliance docs | BRC, HACCP, insurance, allergen, recall |
| P0 | Define first SKU structure | 10–12 main meals |
| P0 | Build SKU cost table | Cost, price, margin, shelf life |
| P1 | Confirm drink menu | Coffee + milk tea pricing |
| P1 | Confirm halal labelling rule | Selected certified meals only |

## Week 2–4｜Site search and compliance preparation
| Priority | Task | Output |
|---|---|---|
| P0 | Shortlist 3–5 City sites | Site comparison table |
| P0 | Verify Class E / food retail use | Landlord confirmation |
| P0 | Verify power capacity | Three-phase, 60–75kVA target |
| P0 | Estimate total occupancy cost | Rent + rates + service charge |
| P1 | Prepare Food Business Registration docs | Ready to submit |
| P1 | Prepare SFBB / HACCP outline | Food safety system draft |
| P1 | Confirm VAT treatment assumption | Conservative 20% model |

## Week 4–6｜Lease, layout and registration
| Priority | Task | Output |
|---|---|---|
| P0 | Negotiate lease | Rent, deposit, fit-out period |
| P0 | Electrical load assessment | Commercial electrician review |
| P0 | Submit Food Business Registration | At least 28 days before opening |
| P1 | Finalise 100 sqm layout | FOH/BOH plan |
| P1 | Finalise equipment list | Microwave, fridge, vending, POS |
| P1 | Build product label template | Ingredients, allergens, use-by, reheating |
| P1 | Set inventory rules | 10-left warning, 5-left app alert, sold-out lock |
