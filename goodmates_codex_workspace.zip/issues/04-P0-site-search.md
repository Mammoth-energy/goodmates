# P0｜Start City of London site search

## Goal
Shortlist 3–5 suitable London City sites.

## Checklist
- [ ] 80–100 sqm
- [ ] Class E / café / food retail use
- [ ] Three-phase power
- [ ] 60–75kVA target
- [ ] Suitable frontage
- [ ] Office cluster nearby
- [ ] Delivery and waste route
- [ ] Rent within model tolerance
