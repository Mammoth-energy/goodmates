# P1｜Prepare food safety and compliance system

## Goal
Prepare for Food Business Registration, SFBB/HACCP and store inspection.

## Checklist
- [ ] Food Business Registration draft
- [ ] Supplier approval file
- [ ] Temperature logs
- [ ] Reheating SOP
- [ ] Cleaning schedule
- [ ] Allergen matrix
- [ ] Label template
- [ ] Recall procedure
- [ ] Staff training checklist
