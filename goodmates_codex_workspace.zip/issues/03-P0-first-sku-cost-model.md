# P0｜Build first SKU cost and margin model

## Goal
Define the first 10–12 SKUs and confirm commercial viability.

## Checklist
- [ ] List 10–12 main meals
- [ ] Assign cuisine category
- [ ] Confirm supplier cost
- [ ] Confirm selling price
- [ ] Calculate VAT-adjusted net revenue
- [ ] Calculate gross margin
- [ ] Mark vending suitability
- [ ] Mark halal certification status
- [ ] Mark allergen profile
