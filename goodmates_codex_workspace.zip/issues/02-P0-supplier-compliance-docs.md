# P0｜Collect central kitchen compliance documents

## Goal
Confirm that the supplier is suitable for GOODMATES ready-meal production.

## Checklist
- [ ] BRC certificate
- [ ] Food business registration
- [ ] Food hygiene rating
- [ ] HACCP / food safety system
- [ ] Insurance certificate
- [ ] Allergen control policy
- [ ] Recall procedure
- [ ] Shelf-life testing information
- [ ] Halal documentation for selected SKUs
