# P0｜Secure central kitchen supply agreement

## Goal
Get Tom’s standard supply agreement / onboarding pack and establish formal cooperation framework.

## Checklist
- [ ] Send contract request email to Tom
- [ ] Receive standard supply agreement
- [ ] Receive onboarding forms
- [ ] Review payment terms
- [ ] Review MOQ and delivery terms
- [ ] Review confidentiality / IP clauses
- [ ] Review labelling and allergen responsibility
- [ ] Review quality rejection / recall terms
